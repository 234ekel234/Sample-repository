# Shell Scripting

Discussion videos:
* https://youtu.be/kZnw2t0LLBw
* https://youtu.be/E3k1F_Qe_xE
* https://youtu.be/QlOW6EF7mT4
* https://youtu.be/z0nuIkr9XIw

Submission details: Create the necessary files as stated in the exer specification and place it on the `exercise` folder.
