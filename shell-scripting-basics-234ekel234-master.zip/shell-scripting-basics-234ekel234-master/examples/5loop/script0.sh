#!/bin/bash
# prints the contents of the array via a c-like loop


array=(zero one two three four five six seven eight nine ten)


for ((i=0; i<10; i++)); do
  echo $i ${array[i]}
done

