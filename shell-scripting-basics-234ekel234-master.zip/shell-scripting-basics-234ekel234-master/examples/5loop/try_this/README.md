Create a shell script that will create a backup of the files from the positional arguments.
A file is considered to be a backup if it ends with `.bak`
