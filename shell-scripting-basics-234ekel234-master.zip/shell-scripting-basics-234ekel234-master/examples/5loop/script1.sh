#!/bin/bash
# prints the contents of the array via a shell-like loop


array=(one two three four five six seven eight nine ten)


for i in ${array[@]}; do
  echo $i
done
