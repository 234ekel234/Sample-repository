#!/bin/bash
# searches a file and checks whether it's a dir or file


if [[ -z $file ]]; then
  echo -n "Enter filename: "
  read file
fi

echo Searching for $file...


if [[ -f $file ]]
  then
  echo $file is a file!
elif [[ -d $file ]]
  then
  echo $file is a directory!
else
  echo $file is unknown :\(
fi
