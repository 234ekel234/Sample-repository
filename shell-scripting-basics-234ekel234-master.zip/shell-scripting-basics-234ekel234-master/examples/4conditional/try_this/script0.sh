#!/bin/bash


mv foo/ba .
# inentional typo at line 4
rm -rf foo
