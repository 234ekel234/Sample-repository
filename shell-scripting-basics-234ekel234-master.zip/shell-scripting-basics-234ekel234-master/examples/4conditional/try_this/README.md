Check the contents of the `foo` directory as well as `script0.sh`

Without changing anything, run the script.

As you can see, the script outputted an error however it still proceeded with the next command. If you are not careful enough, you might harm the system you are using.

In order to resolve this, correct the typo and add a `&&` at the end of line 4.


In summary, you should:

1. Check for typos or always echo the commands in your script first before executing
2. Use conditional execution whenever necessary
3. Be careful when using `rm -rf` especially with `sudo`
