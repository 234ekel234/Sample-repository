#!/bin/bash
# checks if the pos arg 1 is >, <, or = 42


[[ $# -ne 1 ]] && echo $0: should only have exactly one argument && exit

if [[ $1 -gt 42 ]]; then
  echo $1 is greater than 42
elif [[ $1 -lt 42 ]]; then
  echo $1 is less than 42
else
  echo $1 is equal to 42
fi
