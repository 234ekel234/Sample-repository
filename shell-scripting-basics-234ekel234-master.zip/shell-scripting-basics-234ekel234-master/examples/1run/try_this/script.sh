#!/bin/bash

echo "Hello I'm at '`pwd`'"
cd foo
echo "now I'm at '`pwd`'"
