#!/bin/bash


gcc main.c
./a.out
