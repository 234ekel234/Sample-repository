#!/bin/bash
# $@ is not an array

echo $@ # prints all pos args
echo ${#@} # prints the num of pos args
echo ${@[1]} # prints an error

args=($@) # one way to convert $@ to an array
echo ${args} # args is now an array
