#include "print_odd.h"

int main() {
  printOdd(10);
}
