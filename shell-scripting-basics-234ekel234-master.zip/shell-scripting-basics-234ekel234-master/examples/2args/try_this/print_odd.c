#include <stdio.h>
#include "print_odd.h"

void printOdd(int n) {
  int i;

  for (i=0; i<n; i++) {
    if (i%2) printf("%d ", i);
  }

  printf("\n");
}
