#!/bin/bash


gcc $@ -o ${1%.c}
./${1%.c}
