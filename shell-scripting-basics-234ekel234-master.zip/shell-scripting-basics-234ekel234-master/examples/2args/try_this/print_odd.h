void printOdd(int);
