void printEven(int);
