Create a shell script that compiles and outputs an executable with the same name (without the .c) as the file having the main function. The shell script should also run the program afterwards.

sample command
```
./my_script.sh even.c print_even.c
  # compiles both files;
  # outputs an executable named 'even'
  # runs the executable file
```
